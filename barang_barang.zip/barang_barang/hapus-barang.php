<?php
include 'function.php';
$no = $_GET ["no"];
mysqli_query ($conn,"DELETE FROM daftar_barang WHERE no = $no");
if (mysqli_affected_rows ($conn)> 0 ) {
    header  ("Location: data-barang.php");
    exit;

}


?>