<?php
include 'function.php';
$no = $_GET ["no"];
$cari = mysqli_query ($conn, "SELECT*FROM daftar_barang WHERE no = $no");
if (isset ($_POST ["submit"])){
   
    // var_dump($_POST);
  
    $nama =  htmlspecialchars($_POST["nama"]);
        $harga =  htmlspecialchars($_POST["harga"]);
        
        $stok =  htmlspecialchars($_POST["stok"]);
        
       
     

    //$query= "INSERT INTO barang VALUES ('', '$nama', '$harga', '$stok')";
    $cari="UPDATE daftar_barang SET
          
           nama ='$nama',
           harga ='$harga',
           stok ='$stok'
           
            WHERE no=$no";
mysqli_query ($conn, $cari);

//var_dump(mysqli_affected_rows ($conn));
if (mysqli_affected_rows ($conn)>0){
    echo "<script>
    alert ('Data berhasil diedit');
    document.location.href='data-barang.php';
    </script>
    ";

}else{
    echo "<script>
    alert ('Data berhasil diedit');
    document.location.href='data-barang.php';
    </script>
    ";
}


}
?>
<!doctype html>
<html>
    <head><title>Data Barang Toko</title>
          <link rel="stylesheet" type="text/css" href="style.css">
        </head>
    <body>
          <div class="header">
             <div class="header-logo">
             <img src="logo.jpg"alt="ini foto logo">
          </div>
          <div class="header-title">
              <a href="index.php">Data Barang Toko</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="data-barang.php">Data Barang</a></li>
        <li class="menu-item"><a href="tambah-barang.php">Tambah Barang</a></li>
       
      
          </ul>
          <div class="konten">
       <h1>Edit Data Barang</h1>
       <?php
       while($data=mysqli_fetch_assoc ($cari)):
       ?>
       <form action=""method="POST">
       
       <label for="">nama</label>
       <input type="text"name="nama" id= required VALUE="<?php echo $data ["nama"]; ?>">
       <br>
       <label for="">harga</label>
       <input type="text"name="harga" id= required VALUE="<?php echo $data ["harga"]; ?>">
       <br>
       <label for="">stok</label>
       <input type="text"name="stok" id= required VALUE="<?php echo $data ["stok"]; ?>">
       <br>
       
       
       <button type="submit" name="submit">Kirim Edit Data Barang</button>
       </form>
       <?php
       endwhile;
       ?>
       </div>

       <div class="fotter">
            <p>Copyright 2025@Olivia</p>
        </div>

</body>
</html>