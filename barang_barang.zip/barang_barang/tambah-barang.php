<?php
$conn = mysqli_connect("localhost", "root","","barang");

if(isset($_POST["submit"])){
//var_dump($_POST ["barang"]);
$nama = htmlspecialchars ($_POST ["nama"]);
$harga = htmlspecialchars ($_POST ["harga"]);
$stok = htmlspecialchars ($_POST ["stok"]);
$cari = "INSERT INTO daftar_barang
        VALUES ('', '$nama', '$harga' , '$stok')";
        mysqli_query ( $conn,$cari);
        if (mysqli_affected_rows($conn) >0)
        echo "<script>
        alert ('Data Berhasil Ditambahkan');
        document.location.href='data-barang.php';     
        </script>
        ";

        
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
        <div class="header-logo">
            <img src="logo.jpg" alt="Gambar Logo" >
        </div>
        <div class="header-title">
            <a href="index.php"> Data Barang Toko</a>
        </div>
    </div>
	<ul class="menu">
    <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="data-barang.php">Data Barang</a></li>
        <li class="menu-item"><a href="tambah-barang.php">Tambah Barang</a></li>
      
    </ul>
    <div class="konten">
    <h3>Tambah Data Barang</h3>
    <form action="" method="post">
        <label for="">Nama</label>
        <input type="text" name="nama" id="nama" required>
        <br>
        <label for="">Harga</label>
        <input type="text" name="harga" id="harga" required>
        <br>
        <label for="">Stok</label>
        <input type="text"  name="stok" id=" stok"  required>
        <br>
        
        <button type="submit" name="submit">Tambahkan</button>

    </form>
    <div class="fotter">
        <P>Copyright 2025@Olivia</P> 
 
     </div>    
</body>
</html> 