<?php
$koneksi=mysqli_connect("localhost", "root", "", "barang");
$cari=mysqli_query($koneksi,"SELECT*FROM daftar_barang");
if (isset ($_POST["cari"])){
    $pencarian =$_POST ["pencarian"];
    $cari_data="SELECT*FROM daftar_barang Where 
    nama like '%$pencarian%' or
    harga like '%$pencarian%' or
    stok like '%$pencarian%' or";
    
    $cari = mysqli_query ($koneksi,$cari_data);
} else {
    $cari=mysqli_query($koneksi,"SELECT*FROM daftar_barang");
}
?>
<!doctype html>
<html>
    <head><title>Data Barang Toko</title>
          <link rel="stylesheet" type="text/css" href="style.css">
        </head>
    <body>
          <div class="header">
             <div class="header-logo">
             <img src="logo.jpg"alt="ini foto saya">
          </div>
          <div class="header-title">
              <a href="index.php">Data Barang Toko</a>
              
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="data-barang.php">Data Barang</a></li>
        <li class="menu-item"><a href="tambah-barang.php">Tambah Barang</a></li>

          </ul>
          <div class="konten">
             <h1>Data Barang Toko</h1>
             <form action="" method="post">
             <input class="input_b" type="text" name="pencarian"placeholder ="ketik pencarian..." autofocus autocoplate="OFF" >
             <button type="submit" name="cari">Cari</button>
             </form>
              <table class="tabel">
                <tr class="tabel-header">
                    <th>No</th>
                    <th>Nama Barang</th>
                    <th>Harga Barang</th>
                    <th>Stok Barang</th>
                    <th>Keterangan</th>
                </tr>
                <?php 
                $nomor=1;
                ?>
                <?php while($data=mysqli_fetch_assoc($cari)):
            ?>
                <tr class="tabel-konten">
                <td><?php echo $nomor; ?></td>
                   
                    <td><?php echo $data ["nama"];?></td>
                    <td><?php echo $data ["harga"];?></td>
                    <td><?php echo $data ["stok"];?></td>
                    <td>
                    <a href="edit-barang.php?no=<?=   $data ["no"]; ?> ">Edit</a> |
                        <a href="hapus-barang.php?no=<?=  $data ["no"]; ?> "onclick = "return confirm ('Apakah anda yakin?')">Hapus</a>
                    </td>
                </tr>
                <?php
                $nomor ++;
                ?>
                <?php
                endwhile;
                ?>
</table>
          </div>
          <div class="fotter">
            <p>Copyright 2025@Olivia</p>
          </div>
    </body>
</html>