<!DOCTYPE html>
<html>
    <head><title>Data Barang Toko</title>
          <link rel="stylesheet" type="text/css" href="style.css">
        </head>
    <body>
          <div class="header">
             <div class="header-logo">
             <img src="logo.jpg" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">Data Barang Toko</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="data-barang.php">Data Barang</a></li>
        <li class="menu-item"><a href="tambah-barang.php">Tambah Barang</a></li>
      
          </ul>
          <div class="konten">
            <h1>Selamat datang di halaman Daftar Barang Toko kami!</h1>
            <h4>Dengan adanya website daftar barang ini, kami berharap dapata membantu anda dalam mencari  </h4>
             <h4>data barang yang anda butuhkan, dan mempermudah dapat mempermudah anda untuk Menambah </h4>
             <h4>data barang, Edit data barang, dan Hapus data barang dengan mudah dan cepat.</h4>
          </div>
          <div class="fotter">
            <p>Copyright 2025@Olivia</p>
          </div>
    </body>
</html>